#!/usr/bin/env python

import os
import sys

os.system("/home/rosalina/Documents/App/mgltools/bin/pythonsh /home/rosalina/Documents/App/mgltools/MGLToolsPckgs/AutoDockTools/Utilities24/prepare_dpf4.py -l ./4PMM_ligand.pdbqt -r ./4PMM_protein.pdbqt")

#pythonsh prepare_dpf4.py -l ligand_pdbqt_file -r receptor_pdbqt_file