#!/usr/bin/env python

import os
import sys

os.system("/home/rosalina/Documents/App/mgltools/bin/pythonsh /home/rosalina/Documents/App/mgltools/MGLToolsPckgs/AutoDockTools/Utilities24/summarize_results4.py -l ./4pmm_ligand.pdb")

##pythonsh summarize_results4.py -d directory