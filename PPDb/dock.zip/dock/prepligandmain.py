#!/usr/bin/env python
import subprocess

subprocess.Popen('/home/rosalina/Documents/App/mgltools/bin/pythonsh';'/home/rosalina/Documents/App/mgltools/MGLToolsPckgs/AutoDockTools/Utilities24/prepare_ligand4.py -l ./4pmm_ligand.pdb')

