#!/usr/bin/env python

import os
import sys

os.system("/home/rosalina/Documents/App/mgltools/bin/pythonsh /home/rosalina/Documents/App/mgltools/autodocksuite/autodock4.exe -p /home/rosalina/Documents/App/PPDb/static/clean/4pmm/4pmm.dpf -l /home/rosalina/Documents/App/PPDb/static/clean/4pmm/4pmm.dlg &")

#pythonsh autodock4 -p my_docking.dpf -l my_docking.dlg &